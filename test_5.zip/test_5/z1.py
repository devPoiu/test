



def newYear(month, day):
    month -= 1
    year = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if 0 <= month < 13 and 0 < day < year[month]:
        sum = year[month] - day
        for i in range(month+1, len(year)):
            sum += year[i]
        return sum
    else:
        return -1

if __name__ == '__main__':
    print(newYear(3, 18))
    print(newYear(1, 40))
    print(newYear(-13, 40))