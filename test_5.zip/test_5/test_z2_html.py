import pytest
from z2 import PostReach, SponsoredAds, ViralOrganic


class TestPostReachSystem:

    @pytest.mark.parametrize(
        "current_reach, penalty, expected",
        [
            (1000.0, 0.3, 300.0),
            (500.0, 0.5, 250.0),
            (2500.0, 0.0, 0.0),
        ],
    )
    def test_report_penalty(self, current_reach, penalty, expected):
        post = PostReach(base_rank=100, has_video=False)
        assert post.apply_report_penalty(current_reach, penalty) == expected

    def test_reset_metrics(self):
        post = PostReach(base_rank=150.5, has_video=True)
        assert post.reset_metrics() == 150.5

    @pytest.mark.parametrize(
        "actual_comm, shares, saves, bonus, expected",
        [
            (15, 5, 2, 10.0, 100.0 + (15 - 10) + 10.0 + (5 + 2)),
            (5, 10, 10, 10.0, 100.0),
            (10, 0, 0, 5.0, 100.0),
        ],
    )
    def test_viral_organic_priority(self, actual_comm, shares, saves, bonus, expected):
        organic_post = ViralOrganic(base_rank=100.0, comm_limit=10)
        res = organic_post.calculate_priority(actual_comm, shares, saves, video_bonus=bonus)
        assert res == expected

    def test_viral_organic_metadata(self):
        organic_post = ViralOrganic(base_rank=50, comm_limit=5)
        organic_post.set_content_rules("Sport", "RU")
        assert organic_post.topic_id == "Sport"
        assert organic_post.language_code == "RU"
        assert "Organic" in organic_post.get_reach_report(500, 15.5)

    @pytest.mark.parametrize(
        "budget, ctr, match, expected",
        [
            (100.0, 0.1, 0.8, (10.0 * (100.0 * 1.1)) + (50.0 * 0.8)),
            (0.0, 0.2, 0.5, (10.0 * 0.0) + (50.0 * 0.5)),
        ],
    )
    def test_sponsored_ads_priority(self, budget, ctr, match, expected):
        ads_post = SponsoredAds(base_rank=10.0, video_bonus=50.0)
        res = ads_post.calculate_priority(budget, ctr, match)
        assert pytest.approx(res) == expected

    def test_sponsored_ads_metadata(self):
        ads_post = SponsoredAds(base_rank=20, video_bonus=15)
        ads_post.set_content_rules("BILL-992", "USD")
        assert ads_post.billing_id == "BILL-992"
        assert ads_post.currency_type == "USD"
        assert "CPM" in ads_post.get_reach_report(150.0, 2.5)
