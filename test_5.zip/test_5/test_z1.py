import pytest
from z1 import newYear

@pytest.mark.parametrize("month, day, expected", [
    (1, 1, 364),    # Начало года
    (12, 31, 0),    # Конец года (Новый год)
    (3, 1, 305),    # Обычная дата
    (2, 28, 306),   # Конец февраля
    (0, 5, -1),     # Некорректный месяц (нижняя граница)
    (13, 1, -1),    # Некорректный месяц (верхняя граница)
    (5, 0, -1),     # Некорректный день (нижняя граница)
    (4, 31, -1),    # Некорректный день для апреля
])
def test_new_year_days(month, day, expected):
    assert newYear(month, day) == expected


# pytest test_z1.py