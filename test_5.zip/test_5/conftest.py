import html
from datetime import datetime
import pytest


def pytest_html_results_table_header(cells):
    cells.insert(1, '<th class="sortable time" data-column-type="time">Время запуска</th>')
    cells.insert(2, "<th>Описание чек-листа / Test Case</th>")
    cells.pop()


def pytest_html_results_table_row(report, cells):
    description = getattr(report, "description", "Описание отсутствует")
    safe_description = html.escape(description)
    current_time = datetime.now().strftime("%H:%M:%S")

    cells.insert(1, f"<td>{current_time}</td>")
    cells.insert(2, f"<td>{safe_description}</td>")
    cells.pop()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()

    if item.function.__doc__:
        report.description = item.function.__doc__.split("\n")[0].strip()
    else:
        report.description = "Описание отсутствует"
