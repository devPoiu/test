



class PostReach:
    def __init__(self, base_rank:float, has_video:bool):
        self.base_rank = base_rank
        self.has_video = has_video

    def apply_report_penalty(self, current_reach:int, report_penalty:float):
        return current_reach * report_penalty
    
    def reset_metrics(self):
        return self.base_rank


class ViralOrganic(PostReach):
    def __init__(self, base_rank: float, comm_limit: int, has_video: bool = False):
        super().__init__(base_rank, has_video)
        self.comm_limit = int(comm_limit)
        self.topic_id = None
        self.language_code = None

    def calculate_priority(self, actual_comments:int, share_count:int, save_count:int, video_bonus:float = 5.0):
        priority = self.base_rank
        if actual_comments > self.comm_limit:
            engagement = float(share_count + save_count)
            priority += (actual_comments - self.comm_limit) + video_bonus + engagement
        return float(priority)

    def set_content_rules(self, topic_id:str, language_code:str):
        self.topic_id = str(topic_id)
        self.language_code = str(language_code)

    def get_reach_report(self, unique_viewers:int, avg_watch_time:float):
        return f'Увидевших пост:{unique_viewers}, Среднее время:{avg_watch_time}s'


class SponsoredAds(PostReach):
    def __init__(self, base_rank:float, video_bonus:float, has_video:bool = True):
        super().__init__(base_rank, has_video)
        self.video_bonus = float(video_bonus)
        self.billing_id = None
        self.currency_type = None

    def calculate_priority(self, ad_budget:float, click_rate:float, target_match:float):
        effective_budget = ad_budget * (1.0 + click_rate)
        priority = (self.base_rank * effective_budget) + (self.video_bonus * target_match)
        return float(priority)

    def set_content_rules(self, billing_id:str, currency_type:str):
        self.billing_id = str(billing_id)
        self.currency_type = str(currency_type)

    def get_reach_report(self, cpm_cost:float, conversion_pct:float):
        return f"Ads Report: CPM {cpm_cost}, Conversion: {conversion_pct}%"