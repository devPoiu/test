from datetime import datetime
import pprint


class QueueSort:
    def __init__(self, list):
        self.list = sorted(list, key=lambda i: (-i['PR'], i['T'].timestamp()))
        self.arr = []
        for i in self.list:
            self.arr.append(i['id'])

    def __str__(self):
        return str(self.arr)
    

if __name__ == "__main__":

    list = [
        {'id': 1, 'PR': 2, 'T': datetime(2026, 5, 21, 10, 0)},
        {'id': 2, 'PR': 5, 'T': datetime(2026, 5, 21, 11, 0)},
        {'id': 3, 'PR': 4, 'T': datetime(2026, 5, 21, 9, 0)},
        {'id': 4, 'PR': 5, 'T': datetime(2026, 5, 21, 8, 0)},
    ]

    q = QueueSort(list)
    print(q)