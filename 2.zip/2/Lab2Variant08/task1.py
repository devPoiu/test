

class Dropship:
    def __init__(self, p, m):
        self.p = p
        self.m = p * m
        self.f = 5

    def __str__(self):
        return str(self.p + self.m + self.f)


if __name__ == "__main__":
    drop = Dropship(15, 0.3)
    print(drop)
    drop = Dropship(0, 0)
    print(drop)
    drop = Dropship(-10, 2)
    print(drop)
    drop = Dropship("sdgfyu", 0.5)
    print(drop)
    drop = Dropship(20, "sdgfyu")
    print(drop)