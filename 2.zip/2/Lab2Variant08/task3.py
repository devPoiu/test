class Check:
    def __init__(self, sum, n):
        kop = int(round(sum * 100))
        dol = kop // n
        ost = kop % n
        self.doli = [dol / 100] * n
        self.doli[0] = (dol + ost) / 100

    def __str__(self): 
        return str(self.doli)
    


if __name__ == "__main__":    
    q = Check(31, 3)
    print(q)