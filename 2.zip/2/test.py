from datetime import datetime
from Lab2Variant08.task1 import Dropship
from Lab2Variant08.task2 import QueueSort
from Lab2Variant08.task3 import Check

print("Dropship")
drop = Dropship(15, 0.3)
print(f"Тест 1.1: {drop}")
drop = Dropship(0, 0)
print(f"Тест 1.2: {drop}")
drop = Dropship(-10, 2)
print(f"Тест 1.3: {drop}")
try:
    drop = Dropship("sdgfyu", 0.5)
    print(f"Тест 1.4: {drop}")
except TypeError as e:
    print(f"Тест 1.4: Ошибка получена успешно -> {e}")
try:
    drop = Dropship(20, "sdgfyu")
    print(f"Тест 1.5: {drop}")
except TypeError as e:
    print(f"Тест 1.5: Ошибка получена успешно -> {e}")



print("\nQueueSort")
list_2_1 = [
    {'id': 1, 'PR': 2, 'T': datetime(2026, 5, 21, 10, 0)},
    {'id': 2, 'PR': 5, 'T': datetime(2026, 5, 21, 11, 0)}
]
q = QueueSort(list_2_1)
print(f"Тест 2.1:\n{q}")
list_2_2 = [
    {'id': 1, 'PR': 5, 'T': datetime(2026, 5, 21, 11, 0)},
    {'id': 2, 'PR': 5, 'T': datetime(2026, 5, 21, 8, 0)}
]
q = QueueSort(list_2_2)
print(f"Тест 2.2:\n{q}")
list_2_3 = [
    {'id': 1, 'PR': 5, 'T': datetime(2026, 5, 21, 10, 0)},
    {'id': 2, 'PR': 5, 'T': datetime(2026, 5, 21, 10, 0)}
]
q = QueueSort(list_2_3)
print(f"Тест 2.3:\n{q}")
q = QueueSort([])
print(f"Тест 2.4:\n{q}")
try:
    q = QueueSort("не список")
    print(f"Тест 2.5:\n{q}")
except TypeError as e:
    print(e)


print("\nCheck")
q = Check(31, 3)
print(f"Тест 3.1: {q}")
q = Check(30, 3)
print(f"Тест 3.2: {q}")
q = Check(15.75, 1)
print(f"Тест 3.3: {q}")
q = Check(0, 5)
print(f"Тест 3.4: {q}")
# try:
#     q = Check(50, 0)
#     print(f"Тест 3.5: {q}")
# except ValueError as e:
#     print(f"Тест 3.5: Ошибка получена успешно -> {e}")
try:
    q = Check(50, -2)
    print(f"Тест 3.6: {q}")
except ValueError as e:
    print(f"Тест 3.6: Ошибка получена успешно -> {e}")
